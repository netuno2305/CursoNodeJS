const { app } = require('./');

app.listen(3333);